export var command = 'ical.widget/icalBuddy  --noRelativeDates --dateFormat "date: %a %b %e %Y|" --timeFormat "%H:%M:%S GMT%z" --bullet "event: " eventsToday+6';
export var refreshFrequency = 60000 * 5; // ms
var colors = [
    "#ef5350",
    "#ec407a",
    "#ab47bc",
    "#7e57c2",
    "#5c6bc0",
    "#42a5f5",
    "#29b6f6",
    "#26c6da",
    "#26a69a",
    "#66bb6a",
    "#9ccc65",
    "#d4e157",
    "#ffee58",
    "#ffca28",
    "#ffa726",
    "#ff7043",
    "#8d6e63"
];
var transformICalBuddyOutput = function (output) {
    return output
        .split("event: ")
        .filter(function (line) { return line !== ""; })
        .map(function (eventString) {
        var eventLines = eventString.split("\n");
        var nameLine = eventLines[0];
        var locationLine = eventLines.find(function (line) { return line.includes("location:"); });
        var dateLine = eventLines.find(function (line) { return line.includes("date:"); });
        var dateAndTimeSeparatorIndex = dateLine.indexOf("|");
        var date = dateLine.substring(dateLine.indexOf(": ") + 2, dateAndTimeSeparatorIndex);
        var timeSeparatorIndex = dateLine.lastIndexOf(" - ");
        var startTimeString = (timeSeparatorIndex !== -1 &&
            dateLine.substring(dateAndTimeSeparatorIndex + 5, timeSeparatorIndex)) ||
            null;
        var endTimeString = (timeSeparatorIndex !== -1 &&
            dateLine.substring(timeSeparatorIndex + 3)) ||
            null;
        var startTime = new Date(date + ((startTimeString && " " + startTimeString) || ""));
        var endTime = new Date(date + ((endTimeString && " " + endTimeString) || ""));
        var attendeesLine = eventLines.find(function (line) {
            return line.includes("attendees:");
        });
        var calendarStartIndex = nameLine.lastIndexOf("(");
        var calendarEndIndex = nameLine.lastIndexOf(")");
        return {
            name: nameLine.substring(0, calendarStartIndex - 1),
            location: locationLine &&
                locationLine.substring(locationLine.indexOf(": ") + 2),
            startTime: startTime,
            endTime: endTime,
            allDay: startTime.getHours() === 0 &&
                startTime.getMinutes() === 0 &&
                startTime.getTime() === endTime.getTime(),
            attendees: (attendeesLine &&
                attendeesLine.substring(attendeesLine.indexOf(": ") + 2)) ||
                undefined,
            calendar: nameLine.substring(calendarStartIndex + 1, calendarEndIndex)
            // rawLines: eventLines
        };
    });
};
function groupBy(xs, getGroupValue, valuesAreEqual) {
    if (valuesAreEqual === void 0) { valuesAreEqual = function (v1, v2) { return v1 === v2; }; }
    return xs.reduce(function (acc, x) {
        var value = getGroupValue(x);
        var existingIndex = acc.findIndex(function (el) { return valuesAreEqual(el.group, value); });
        if (existingIndex !== -1) {
            acc[existingIndex].elements.push(x);
        }
        else {
            acc.push({ group: value, elements: [x] });
        }
        return acc;
    }, []);
}
function getStringNumber(s) {
    return s.split("").reduce(function (acc, curr, i) { return acc + s.charCodeAt(i); }, 0);
}
export var render = function (_a) {
    var output = _a.output;
    var today = new Date();
    today.setHours(0, 0, 0, 0);
    var transformedOutput = transformICalBuddyOutput(output);
    return (<div>
      {groupBy(transformedOutput, function (event) { return event.startTime; }, function (v1, v2) { return v1.toDateString() === v2.toDateString(); })
        .slice(0, 3)
        .map(function (group) {
        var events = group.elements;
        var eventsDay = new Date(group.group);
        eventsDay.setHours(0, 0, 0, 0);
        var daysFromToday = Math.floor((eventsDay - today) / (1000 * 60 * 60 * 24));
        return (<div>
              <h5 className={"date"}>
                {(daysFromToday === 0
            ? "Today"
            : daysFromToday === 1
                ? "Tomorrow"
                : daysFromToday === 2
                    ? "Day After Tomorrow"
                    : group.group.toLocaleString() +
                        (" (" + daysFromToday + " days from today)")).toUpperCase()}
              </h5>
              <div>
                {events.map(function (event) {
            return (<div className="event">
                      <span className="calendar" style={{
                backgroundColor: colors[getStringNumber(event.calendar) % colors.length]
            }}>
                        {event.calendar}
                      </span>
                      <div className="eventBody">
                        <div className="data">
                          <h4 className="name">{event.name}</h4>
                          <div className="times">
                            {!event.allDay ? <span>
                            <span className="time start">
                              {event.startTime.toLocaleTimeString(undefined, {
                hour12: true,
                hour: "numeric",
                minute: "2-digit"
            })}
                            </span>
                            {event.endTime && (<span>
                                {" "}
                                -{" "}
                                <span className="time end">
                                  {event.endTime.toDateString() !==
                event.startTime.toDateString()
                ? event.endTime.toLocaleString()
                : event.endTime.toLocaleTimeString(undefined, {
                    hour12: true,
                    hour: "numeric",
                    minute: "2-digit"
                })}
                                </span>
                              </span>)}
                            </span> :
                <span className={"time allDay"}>All Day</span>}
                          </div>
                          {event.location && (<p className="property location">
                              {event.location}
                            </p>)}
                          {event.attendees && (<p className="property attendees">
                              with {event.attendees}
                            </p>)}
                          {event.notes && (<p className="property notes">{event.notes}</p>)}
                          {event.rawLines && (<p>{JSON.stringify(event.rawLines)}</p>)}
                        </div>
                      </div>
                    </div>);
        })}
              </div>
            </div>);
    })}
    </div>);
};
var width = 400;
var metadataWidth = 100;
export var className = {
    left: 25,
    bottom: 20,
    fontFamily: "system, -apple-system",
    color: "#E9E9E9",
    width: width,
    ".date": {
        marginBottom: 10,
        color: "#AAAAAA"
    },
    ".event": {
        marginBottom: 20,
        textShadow: "1px 0 5px rgba(0,0,0,0.6)",
        ".eventBody": {
            display: "flex"
        },
        ".metadata": {
            width: metadataWidth,
            marginLeft: 5,
            textAlign: "right"
        },
        ".data": {
            width: width - metadataWidth
        },
        ".times": {
            marginTop: 2,
            marginBottom: 2,
            fontSize: "0.85em",
            color: "#BBBBBB"
        },
        ".time": {
            ".soon": {},
            ".now": {}
        },
        ".property": {
            marginTop: 2,
            marginBottom: 2,
            fontSize: "0.75em",
            color: "#909090"
        },
        ".name": {
            marginTop: 0,
            marginBottom: 2.5,
            marginRight: 10,
            verticalAlign: "top",
            lineHeight: 1.3
        },
        ".calendar": {
            backgroundColor: "white",
            borderRadius: 100,
            marginBottom: 2.5,
            color: "black",
            padding: "2px 5px",
            fontSize: "0.7em",
            display: "inline-block",
            verticalAlign: "middle",
            textShadow: "none"
        },
        ".location": {},
        ".attendees": {},
        ".notes": {}
    }
};
